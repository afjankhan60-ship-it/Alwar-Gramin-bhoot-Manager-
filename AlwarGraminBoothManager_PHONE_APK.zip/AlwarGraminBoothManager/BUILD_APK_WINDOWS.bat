@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle command nahi mila.
  echo BUILD_APK_HI.txt padhein aur Android Studio se Build APK karein.
  pause
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 (
  echo Build fail hua. Android Studio me Gradle Sync aur SDK 35 check karein.
  pause
  exit /b 1
)
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
