package com.alwargramin.boothmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF123B70)
private val Blue = Color(0xFF1976D2)
private val Pale = Color(0xFFEAF3FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Blue)) { BoothManagerApp() } }
    }
}

@Composable
fun BoothManagerApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("home") }
    var user by remember { mutableStateOf("") }
    var hindi by remember { mutableStateOf(true) }
    if (!loggedIn) LoginScreen(hindi, { hindi = !hindi }) { entered -> user = entered; loggedIn = true }
    else MainScreen(user, hindi, { hindi = !hindi }, page, { page = it }, { loggedIn = false })
}

@Composable
fun LoginScreen(hindi: Boolean, toggle: () -> Unit, onLogin: (String) -> Unit) {
    var id by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var showMessage by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Pale), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().padding(22.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(76.dp).background(Navy, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.HowToVote, null, tint = Color.White, modifier = Modifier.size(42.dp)) }
                Spacer(Modifier.height(14.dp))
                Text("ALWAR GRAMIN", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("BOOTH MANAGER", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Blue)
                Text(if (hindi) "लॉगिन करें" else "Sign in", modifier = Modifier.padding(top = 18.dp, bottom = 12.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(id, { id = it }, label = { Text(if (hindi) "यूज़र आईडी" else "User ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(pass, { pass = it }, label = { Text(if (hindi) "पासवर्ड" else "Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                if (showMessage) Text(if (hindi) "यह डेमो स्क्रीन है। असली लॉगिन चालू करने के लिए सुरक्षित सर्वर/Firebase जोड़ना बाकी है।" else "Demo screen only. Secure Firebase/server authentication must be connected.", color = Color(0xFFB3261E), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                Button(onClick = { if (id.isNotBlank() && pass.isNotBlank()) onLogin(id) else showMessage = true }, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) { Text(if (hindi) "लॉगिन" else "Login") }
                TextButton(onClick = toggle) { Text(if (hindi) "English / हिंदी" else "हिंदी / English") }
                Text("मुख्य एडमिन: Afjan Khan", color = Navy, fontSize = 13.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(user: String, hindi: Boolean, toggle: () -> Unit, page: String, navigate: (String) -> Unit, logout: () -> Unit) {
    var query by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("ALWAR GRAMIN BOOTH MANAGER", fontSize = 16.sp, fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = toggle) { Text("हिं / EN", color = Color.White) }; IconButton(onClick = logout) { Icon(Icons.Default.Logout, null, tint = Color.White) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)) }, bottomBar = { NavigationBar { listOf("home" to Icons.Default.Home, "booths" to Icons.Default.List, "search" to Icons.Default.Search, "report" to Icons.Default.Assessment).forEach { (key, icon) -> NavigationBarItem(selected = page == key, onClick = { navigate(key) }, icon = { Icon(icon, null) }, label = { Text(when(key) { "home" -> if(hindi) "होम" else "Home"; "booths" -> if(hindi) "बूथ" else "Booths"; "search" -> if(hindi) "खोज" else "Search"; else -> if(hindi) "रिपोर्ट" else "Reports" }) }) } } }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Color(0xFFF7F9FC)).padding(16.dp)) {
            when(page) {
                "home" -> {
                    Text(if(hindi) "नमस्ते, $user" else "Welcome, $user", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Text(if(hindi) "अलवर ग्रामीण विधानसभा • 327 बूथ" else "Alwar Gramin Constituency • 327 Booths", color = Color.Gray)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { StatCard(if(hindi) "कुल बूथ" else "Total Booths", "327", Modifier.weight(1f)); StatCard(if(hindi) "कार्यकर्ता" else "Workers", "50+", Modifier.weight(1f)) }
                    Spacer(Modifier.height(14.dp))
                    listOf("booths" to (if(hindi) "सभी 327 बूथ देखें" else "View all 327 booths"), "search" to (if(hindi) "मतदाता खोजें" else "Search voters"), "report" to (if(hindi) "बूथ रिपोर्ट" else "Booth reports")).forEach { (dest, label) -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { navigate(dest) }, colors = CardDefaults.cardColors(containerColor = Color.White)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ChevronRight, null, tint = Blue); Spacer(Modifier.width(8.dp)); Text(label, fontWeight = FontWeight.SemiBold) } } }
                }
                "booths" -> {
                    Text(if(hindi) "बूथ सूची" else "Booth List", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Text(if(hindi) "बूथ का वास्तविक नाम/मतदाता डेटा जोड़ना बाकी है।" else "Actual booth names and voter data are pending import.", color = Color.Gray, fontSize = 13.sp)
                    LazyColumn { items((1..327).toList()) { n -> Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text("${n}", color = Blue, fontWeight = FontWeight.Bold); Spacer(Modifier.width(14.dp)); Column { Text(if(hindi) "बूथ संख्या $n" else "Booth No. $n", fontWeight = FontWeight.SemiBold); Text(if(hindi) "मतदाता विवरण उपलब्ध नहीं" else "Voter details not added", fontSize = 12.sp, color = Color.Gray) } } } } }
                }
                "search" -> {
                    Text(if(hindi) "मतदाता खोज" else "Voter Search", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), label = { Text(if(hindi) "नाम या वोटर आईडी" else "Name or Voter ID") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    Text(if(hindi) "खोज सुविधा वास्तविक मतदाता सूची आयात होने के बाद सक्रिय होगी।" else "Search will work after the voter roll is imported.", modifier = Modifier.padding(top = 14.dp), color = Color.Gray)
                }
                else -> {
                    Text(if(hindi) "बूथ रिपोर्ट" else "Booth Reports", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Text(if(hindi) "PDF/Excel रिपोर्ट वास्तविक डेटा जोड़ने के बाद उपलब्ध होगी।" else "PDF/Excel reports will be enabled after data import.", modifier = Modifier.padding(top = 12.dp), color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Blue); Text(title, color = Color.Gray, fontSize = 13.sp) } }
}
